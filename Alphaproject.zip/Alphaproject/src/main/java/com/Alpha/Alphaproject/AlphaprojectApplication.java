package com.Alpha.Alphaproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlphaprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlphaprojectApplication.class, args);
	}

}
